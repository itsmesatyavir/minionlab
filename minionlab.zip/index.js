import chalk from "chalk";
import fs from "fs";
import MinionLab from "./main/minionLabConnect.js";
import MinionlabAutoreff from "./main/minionlabAutoreff.js";
import ProxyManager from "./main/proxy.js";
import { logMessage, prompt, rl } from "./utils/logger.js";

async function main() {
  console.clear();
  console.log(
    chalk.blueBright(`
┌────────────────────────────────────────┐
│ 🚀 Minion Lab Tools - By Forest Army   │
├────────────────────────────────────────┤
│github.com/itsmesatyavir t.me/forestarmy│
└────────────────────────────────────────┘
`)
  );

  const choice = await prompt(
    chalk.yellowBright("Choose Mode:\n  1️⃣  Connect Wallet\n  2️⃣  Auto Referral\n> ")
  );

  const proxyManager = new ProxyManager();
  const proxiesLoaded = proxyManager.loadProxies();
  if (!proxiesLoaded) {
    logMessage(null, null, "No proxies loaded. Running on local IP.", "warning");
  }

  if (choice === "1") {
    // Connect Wallet
    if (!fs.existsSync("accounts.txt")) {
      console.log(chalk.red("❌ 'accounts.txt' file not found!"));
      console.log(chalk.yellow("➡️  Create it with format: email:password"));
      process.exit(1);
    }

    const accounts = fs.readFileSync("accounts.txt", "utf8")
      .split("\n")
      .filter(line => line.trim() && !line.startsWith("#"))
      .map(line => {
        const [email, password] = line.trim().split(":");
        return { email, password };
      });

    const count = accounts.length;
    if (count === 0) {
      console.log(chalk.red("❌ No accounts found in 'accounts.txt'"));
      process.exit(1);
    }

    console.log(chalk.green(`✅ Found ${count} accounts to process.`));

    fs.writeFileSync("result.txt", "# Solana Wallet Results\n# Format: email:privatekey\n\n");

    let successful = 0;

    try {
      for (let i = 0; i < count; i++) {
        console.log(chalk.gray("\n" + "-".repeat(60)));
        const currentProxy = await proxyManager.getRandomProxy(i + 1, count);
        const scrape = await MinionLab.create(currentProxy, i + 1, count);

        try {
          const result = await scrape.singleProses(accounts[i].email, accounts[i].password);

          if (result) {
            fs.appendFileSync("result.txt", `${result.email}:${result.privateKeyBase58}\n`);
            successful++;
            logMessage(i + 1, count, `✅ Wallet connected: ${result.email}`, "success");
            logMessage(i + 1, count, `🔑 Public Key: ${result.publicKey}`, "info");
          } else {
            logMessage(i + 1, count, `⚠️ Failed to connect: ${accounts[i].email}`, "error");
          }
        } catch (err) {
          logMessage(i + 1, count, `❌ Error: ${err.message}`, "error");
        }

        if (i < count - 1) await new Promise(res => setTimeout(res, 2000));
      }
    } finally {
      console.log(chalk.magenta("\n🎉 Wallet Connection Completed"));
      console.log(chalk.green(`✅ ${successful} of ${count} wallets connected`));
      console.log(chalk.cyan("📁 Results saved to result.txt"));
      rl.close();
    }

  } else if (choice === "2") {
    // Auto Referral
    const count = parseInt(await prompt(chalk.yellow("📦 How many accounts to create? ")));
    const refCode = await prompt(chalk.yellow("🔗 Enter your referral code: "));

    const accounts = fs.createWriteStream("accounts.txt", { flags: "a" });
    let successful = 0;
    let attempt = 1;

    try {
      while (successful < count) {
        console.log(chalk.gray("\n" + "-".repeat(60)));
        const currentProxy = await proxyManager.getRandomProxy(successful + 1, count);
        const scrape = await MinionlabAutoreff.create(refCode, currentProxy, successful + 1, count);

        try {
          const account = await scrape.singleProses();

          if (account) {
            accounts.write(`${account.email}:${account.password}\n`);
            successful++;
            logMessage(successful, count, `✅ Account created: ${account.email}`, "success");
            attempt = 1;
          } else {
            logMessage(successful + 1, count, "⚠️ Account creation failed, retrying...", "error");
            attempt++;
          }
        } catch (error) {
          logMessage(successful + 1, count, `❌ Error: ${error.message}, retrying...`, "error");
          attempt++;
        }
      }
    } finally {
      accounts.end();
      console.log(chalk.magenta("\n🎉 Account creation complete!"));
      console.log(chalk.green(`✅ Created ${successful} of ${count} accounts`));
      console.log(chalk.cyan("📁 Results saved to accounts.txt"));
      rl.close();
    }

  } else {
    console.log(chalk.red("❌ Invalid input. Exiting..."));
    rl.close();
    process.exit(1);
  }
}

main();
